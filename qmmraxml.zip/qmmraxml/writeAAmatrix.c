// treeLength treefile
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int main (int argc, char *argv[]) 
{ 
  float lens=0, len;
  FILE *infile;
  infile = fopen (argv[1], "r");   
  char *pch, *p;
  int flag;          // remember the position when the characters read
  double aaMut[19][19];

  int i,j;

  for (i=1;i<20;i++) {
    for (j=0;j<i;j++)
      printf("aaMut[%d][%d]=1.0; ",i,j);
    printf("\n");
  }


  for (i=0;i<20;i++) 
    printf("f[%d]=0.05; ",i);
  printf("\n");


  return 0;
}
