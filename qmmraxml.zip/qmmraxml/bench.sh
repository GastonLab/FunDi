#!/bin/bash

./qmmraxmlHPC -m PROTGAMMAJTTF -s cox2.seq -t cox2.tre -f e -n cox2.out.tre1 -L tre1.sitelkh
./qmmraxmlHPC -m PROTGAMMAJTTF -s cox2.seq -t cox2.tre -f e -n cox2.out.tre2 -L tre2.sitelkh
./qmmraxmlHPC -m PROTGAMMAJTTF -s cox2.seq -t cox2.tre -f e -n cox2.out.tre3 -L tre3.sitelkh
./qmmraxmlHPC -m PROTGAMMAJTTF -s cox2.seq -t cox2.tre -f e -n cox2.out.tre4 -L tre4.sitelkh

cat tre1.sitelkh tre2.sitelkh tre3.sitelkh tre4.sitelkh >sitelkh

echo "nall site likelihoods are saved in sitelkh."